HOUSE LTD — PROJETO INICIAL DO ZERO
===================================

ARQUIVOS
- index.html: página principal com seções de ficha, troca, vagas, busca e história.
- style.css: identidade visual responsiva, com fundo preto, laranja e branco.
- app.js: interações de demonstração no navegador.
- admin.html: painel administrativo de demonstração.
- admin.js: gestão local demonstrativa.
- firebase-config.js: modelo de configuração futura do Firebase.
- Fundo.mp4: coloque o vídeo de fundo original nesta mesma pasta.

COMO TESTAR
1. Extraia todos os arquivos para uma pasta.
2. Coloque o vídeo original com o nome exato Fundo.mp4 na pasta.
3. Abra index.html no navegador. Para melhores resultados, use uma hospedagem estática ou servidor local.
4. Use os menus para testar os formulários e a seção de administração.

IMPORTANTE SOBRE O ESTADO ATUAL
Esta é uma primeira versão de interface/protótipo. Os envios são guardados apenas no armazenamento local do navegador (localStorage). Isso significa:
- não chegam à administração em outros dispositivos;
- apagar os dados do navegador pode apagar os registros;
- não é uma base de dados real compartilhada;
- o painel administrativo ainda NÃO possui autenticação segura;
- não publique o painel como área privada real antes de integrar Firebase Authentication e Firestore com regras adequadas.

PARA TRANSFORMAR EM SITE REAL
1. Confirmar o projeto Firebase correto e obter a configuração web em Configurações do projeto > Seus apps.
2. Configurar Firebase Authentication para administradores (não usar senha em HTML ou localStorage).
3. Definir regras Firestore para limitar leituras e gravações; evitar expor telefone ou dados pessoais publicamente.
4. Integrar o catálogo de vagas e os pedidos às coleções definitivas.
5. Testar aprovação/recusa, prevenção de personagens duplicados, trocas atômicas e busca de membro com proteção contra enumeração.
6. Hospedar o site e testar em celular.

DADOS PESSOAIS
O formulário pede apenas os quatro últimos dígitos do telefone, mas isso ainda pode ser dado identificável em conjunto com outras informações. Não publique os cadastros, nem use os quatro dígitos como único mecanismo de autenticação. A busca neste protótipo é somente local.
