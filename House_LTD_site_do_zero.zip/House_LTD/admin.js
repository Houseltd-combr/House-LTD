/* Painel de demonstração: armazenamento local, não é autenticação de produção. */
const KEYS={requests:"ltd_demo_requests_v1",swaps:"ltd_demo_swaps_v1",vacancies:"ltd_demo_vacancies_v1",members:"ltd_demo_members_v1"};
const initial=[{id:"demo-1",character:"Izuku Midoriya",work:"Boku no Hero Academia",status:"available"},{id:"demo-2",character:"Gojo Satoru",work:"Jujutsu Kaisen",status:"available"},{id:"demo-3",character:"Naruto Uzumaki",work:"Naruto",status:"occupied"},{id:"demo-4",character:"Mitsuri Kanroji",work:"Kimetsu no Yaiba",status:"available"},{id:"demo-5",character:"Hinata Hyuga",work:"Naruto",status:"occupied"},{id:"demo-6",character:"Marin Kitagawa",work:"Sono Bisque Doll",status:"available"}];
function read(key){try{const v=JSON.parse(localStorage.getItem(key));return Array.isArray(v)?v:[]}catch{return[]}}
function save(key,value){localStorage.setItem(key,JSON.stringify(value))}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function vacancies(){let v=read(KEYS.vacancies);if(!v.length){v=initial.slice();save(KEYS.vacancies,v)}return v}
let active="requests";
function updateStats(){document.getElementById("pendingCount").textContent=[...read(KEYS.requests),...read(KEYS.swaps)].filter(x=>x.status==="pending").length;document.getElementById("vacancyCount").textContent=vacancies().length;document.getElementById("memberCount").textContent=read(KEYS.members).length}
function render(){
 const root=document.getElementById("adminContent");let rows=[],heads=[];
 if(active==="requests"){heads=["Membro","Personagem","Obra","Contato (4 dígitos)","Status","Ações"];rows=read(KEYS.requests).map((x,i)=>[esc(x.nickname||"—"),esc(x.character),esc(x.work),esc(x.phoneLast4),esc(x.status),actions("requests",i,x.status)]);}
 if(active==="swaps"){heads=["Membro","Atual","Novo","Contato (4 dígitos)","Status","Ações"];rows=read(KEYS.swaps).map((x,i)=>[esc(x.nickname),`${esc(x.oldCharacter)} (${esc(x.oldWork)})`,`${esc(x.newCharacter)} (${esc(x.newWork)})`,esc(x.phoneLast4),esc(x.status),actions("swaps",i,x.status)]);}
 if(active==="vacancies"){heads=["Personagem","Obra","Status","Ações"];rows=vacancies().map((x,i)=>[esc(x.character),esc(x.work),x.status==="occupied"?"Ocupada":"Disponível",`<button data-action="toggle-vacancy" data-index="${i}">${x.status==="occupied"?"Liberar vaga":"Marcar ocupada"}</button><button data-action="delete-vacancy" data-index="${i}">Excluir</button>`]);}
 if(active==="members"){heads=["Apelido","Idade","Personagem","Obra","Status"];rows=read(KEYS.members).map(x=>[esc(x.nickname||"—"),esc(x.age||"—"),esc(x.character),esc(x.work),esc(x.status||"—")]);}
 const add=active==="vacancies"?`<form id="addVacancy" class="form-panel" style="margin-bottom:20px"><div class="form-grid"><label>Personagem<input name="character" required maxlength="80" placeholder="Nome"></label><label>Obra<input name="work" required maxlength="100" placeholder="Universo"></label></div><button class="button button-orange" type="submit" style="margin-top:15px">Adicionar vaga +</button></form>`:"";
 root.innerHTML=add+(rows.length?`<div style="overflow-x:auto"><table class="admin-table"><thead><tr>${heads.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`:`<div class="admin-empty">Ainda não há registros nesta seção neste navegador.</div>`);
 root.querySelectorAll("[data-action]").forEach(btn=>btn.addEventListener("click",()=>act(btn.dataset.action,Number(btn.dataset.index))));
 root.querySelector("#addVacancy")?.addEventListener("submit",e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.currentTarget));const v=vacancies();v.push({id:Date.now().toString(),character:d.character.trim(),work:d.work.trim(),status:"available"});save(KEYS.vacancies,v);render();updateStats()});
}
function actions(type,index,status){return status==="pending"?`<button class="approve" data-action="approve-${type}" data-index="${index}">Aprovar</button><button class="reject" data-action="reject-${type}" data-index="${index}">Recusar</button>`:`<span>—</span>`}
function act(action,index){
 if(action==="toggle-vacancy"){const v=vacancies();if(v[index])v[index].status=v[index].status==="occupied"?"available":"occupied";save(KEYS.vacancies,v)}
 if(action==="delete-vacancy"){const v=vacancies();v.splice(index,1);save(KEYS.vacancies,v)}
 if(action.startsWith("approve-")||action.startsWith("reject-")){
  const type=action.endsWith("requests")?"requests":"swaps",arr=read(KEYS[type]),item=arr[index];if(!item)return;
  item.status=action.startsWith("approve-")?"approved":"rejected";save(KEYS[type],arr);
  if(type==="requests"&&item.status==="approved"){const m=read(KEYS.members);const member=m.find(x=>x.phoneLast4===item.phoneLast4&&x.character===item.character);if(member)member.status="approved";save(KEYS.members,m);const v=vacancies();const vacancy=v.find(x=>x.character.toLowerCase()===item.character.toLowerCase()&&x.work.toLowerCase()===item.work.toLowerCase());if(vacancy)vacancy.status="occupied";save(KEYS.vacancies,v)}
  if(type==="swaps"&&item.status==="approved"){const v=vacancies();const old=v.find(x=>x.character.toLowerCase()===item.oldCharacter.toLowerCase()&&x.work.toLowerCase()===item.oldWork.toLowerCase());if(old)old.status="available";const next=v.find(x=>x.character.toLowerCase()===item.newCharacter.toLowerCase()&&x.work.toLowerCase()===item.newWork.toLowerCase());if(next)next.status="occupied";save(KEYS.vacancies,v)}
 }
 updateStats();render();
}
document.querySelectorAll("[data-tab]").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll("[data-tab]").forEach(b=>b.classList.toggle("active",b===btn));active=btn.dataset.tab;render()}));
updateStats();render();
