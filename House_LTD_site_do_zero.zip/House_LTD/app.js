/* HOUSE LTD — protótipo de interface.
   Os dados ficam apenas neste navegador. Para produção, integrar Firebase e regras seguras. */
const STORAGE = {
  requests: "ltd_demo_requests_v1",
  swaps: "ltd_demo_swaps_v1",
  vacancies: "ltd_demo_vacancies_v1",
  members: "ltd_demo_members_v1"
};
const starterVacancies = [
  {id:"demo-1", character:"Izuku Midoriya", work:"Boku no Hero Academia", status:"available"},
  {id:"demo-2", character:"Gojo Satoru", work:"Jujutsu Kaisen", status:"available"},
  {id:"demo-3", character:"Naruto Uzumaki", work:"Naruto", status:"occupied"},
  {id:"demo-4", character:"Mitsuri Kanroji", work:"Kimetsu no Yaiba", status:"available"},
  {id:"demo-5", character:"Hinata Hyuga", work:"Naruto", status:"occupied"},
  {id:"demo-6", character:"Marin Kitagawa", work:"Sono Bisque Doll", status:"available"}
];
function read(key, fallback=[]) {
  try { const value = JSON.parse(localStorage.getItem(key)); return Array.isArray(value) ? value : fallback; }
  catch { return fallback; }
}
function save(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
function getVacancies() {
  const existing = read(STORAGE.vacancies, null);
  if (existing.length) return existing;
  save(STORAGE.vacancies, starterVacancies);
  return starterVacancies.slice();
}
function clean(value) { return String(value ?? "").trim(); }
function formObject(form) { return Object.fromEntries(new FormData(form).entries()); }
function toast(message) {
  const el = document.getElementById("toast");
  if (!el) return;
  el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 3200);
}
function feedback(id, message) {
  const el = document.getElementById(id);
  if (el) el.textContent = message;
}
function validLast4(value) { return /^[0-9]{4}$/.test(value); }

const navToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
navToggle?.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", String(open));
});
mainNav?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open"); navToggle?.setAttribute("aria-expanded", "false");
}));

document.getElementById("characterForm")?.addEventListener("submit", event => {
  event.preventDefault();
  const data = formObject(event.currentTarget);
  data.age = Number(data.age);
  data.phoneLast4 = clean(data.phoneLast4);
  if (!validLast4(data.phoneLast4)) return feedback("characterFeedback", "Informe exatamente quatro números.");
  const requests = read(STORAGE.requests);
  const request = {id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), ...data, type:"character", status:"pending", createdAt:new Date().toISOString()};
  requests.unshift(request); save(STORAGE.requests, requests);
  const members = read(STORAGE.members);
  members.push({nickname:data.nickname, age:data.age, phoneLast4:data.phoneLast4, character:data.character, work:data.work, photo:data.photo, status:"pending"});
  save(STORAGE.members, members);
  event.currentTarget.reset();
  feedback("characterFeedback", "Solicitação registrada neste navegador como pendente. Para chegar à administração em outros dispositivos, conecte o Firebase.");
  toast("Ficha registrada no protótipo.");
});

document.getElementById("swapForm")?.addEventListener("submit", event => {
  event.preventDefault();
  const data = formObject(event.currentTarget);
  data.phoneLast4 = clean(data.phoneLast4);
  if (!validLast4(data.phoneLast4)) return feedback("swapFeedback", "Informe exatamente quatro números.");
  const swaps = read(STORAGE.swaps);
  swaps.unshift({id:crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), ...data, type:"swap", status:"pending", createdAt:new Date().toISOString()});
  save(STORAGE.swaps, swaps);
  event.currentTarget.reset();
  feedback("swapFeedback", "Pedido de troca registrado neste navegador como pendente. A vaga não muda até a aprovação.");
  toast("Solicitação de troca registrada.");
});

function renderVacancies() {
  const grid = document.getElementById("vacancyGrid");
  if (!grid) return;
  const q = clean(document.getElementById("vacancySearch")?.value).toLocaleLowerCase("pt-BR");
  const filter = document.getElementById("vacancyFilter")?.value || "all";
  const items = getVacancies().filter(item => {
    const matches = `${item.character} ${item.work}`.toLocaleLowerCase("pt-BR").includes(q);
    return matches && (filter === "all" || item.status === filter);
  });
  if (!items.length) { grid.innerHTML = '<div class="empty-state">Nenhum personagem encontrado com esse filtro.</div>'; return; }
  grid.innerHTML = items.map(item => `<article class="vacancy-card"><span class="status ${item.status === "occupied" ? "occupied" : "available"}">${item.status === "occupied" ? "Ocupada" : "Disponível"}</span><h3>${escapeHTML(item.character)}</h3><p>${escapeHTML(item.work)}</p></article>`).join("");
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
document.getElementById("vacancySearch")?.addEventListener("input", renderVacancies);
document.getElementById("vacancyFilter")?.addEventListener("change", renderVacancies);
renderVacancies();

document.getElementById("lookupForm")?.addEventListener("submit", event => {
  event.preventDefault();
  const digits = clean(new FormData(event.currentTarget).get("phoneLast4"));
  const result = document.getElementById("lookupResults");
  if (!validLast4(digits)) { result.textContent = "Digite exatamente quatro números."; return; }
  const requests = read(STORAGE.requests).filter(item => item.phoneLast4 === digits);
  const swaps = read(STORAGE.swaps).filter(item => item.phoneLast4 === digits);
  if (!requests.length && !swaps.length) {
    result.textContent = "Nenhum registro encontrado neste navegador. Isso não consulta os dados de outros membros ou dispositivos.";
    return;
  }
  result.innerHTML = [
    ...requests.map(item => `<div class="result-item"><b>Ficha:</b> ${escapeHTML(item.character)} — ${escapeHTML(item.work)}<br>Status: ${escapeHTML(item.status)}</div>`),
    ...swaps.map(item => `<div class="result-item"><b>Troca:</b> ${escapeHTML(item.oldCharacter)} → ${escapeHTML(item.newCharacter)}<br>Status: ${escapeHTML(item.status)}</div>`)
  ].join("");
});
