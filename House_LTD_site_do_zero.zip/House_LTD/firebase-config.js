/*
  CONFIGURAÇÃO FUTURA DO FIREBASE
  Não cole aqui chaves privadas, senhas ou tokens de administrador.
  Firebase Web config é identificador de projeto, mas as regras do Firestore
  e o Firebase Authentication são essenciais para proteger os dados.
*/
export const firebaseConfig = {
  apiKey: "PREENCHA_COM_A_CONFIGURACAO_WEB_DO_FIREBASE",
  authDomain: "house-ltd.firebaseapp.com",
  projectId: "house-ltd",
  storageBucket: "house-ltd.firebasestorage.app",
  messagingSenderId: "PREENCHA",
  appId: "PREENCHA"
};
